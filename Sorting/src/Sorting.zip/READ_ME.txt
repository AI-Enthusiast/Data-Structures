------ SORTED ------

   --- Round1 Sorted ---
      HeapSort1:PASS
      QuickSort1:PASS
      MergeSort1:PASS

   --- Round2 Sorted ---
      HeapSort2:PASS
      QuickSort2:PASS
      MergeSort2:PASS

   --- Round3 Sorted ---
      HeapSort3:PASS
      QuickSort3:PASS
      MergeSort3:PASS

   --- Variance Sorted ---
      Variance HS1: 75838.88888888889
      Variance HS10: 663077.2933333335
      Variance HS100: 2.107266447111111E7
      Variance HS1000: 1.26127996504E9
      Variance QS1: 157.42666666666668
      Variance QS10: 970.5288888888887
      Variance QS100: 67669.22222222222
      Variance QS1000: 645005.5733333335
      Variance MS1: 4.328888888888889
      Variance MS10: 1023.3155555555555
      Variance MS100: 2665.6933333333336
      Variance MS1000: 2665.6933333333336

   --- Averages Sorted ---
      HeapSort1 average time(μs):0
      HeapSort10 average time(μs):1363
      HeapSort100 average time(μs):5518
      HeapSort1000 average time(μs):39266
      QuickSort1 average time(μs):16
      QuickSort10 average time(μs):55
      QuickSort100 average time(μs):355
      QuickSort1000 average time(μs):1310
      MergeSort1 average time(μs):4
      MergeSort10 average time(μs):58
      MergeSort100 average time(μs):110
      MergeSort1000 average time(μs):619



------ REVERSED ------

   --- Round1 Reversed ---
      HeapSort1:PASS
      QuickSort1:PASS
      MergeSort1:PASS

   --- Round2 Reversed ---
      HeapSort2:PASS
      QuickSort2:PASS
      MergeSort2:PASS

   --- Round3 Reversed ---
      HeapSort3:PASS
      QuickSort3:PASS
      MergeSort3:PASS

   --- Variance Reversed ---
      Variance HS1: 1409.2266666666665
      Variance HS10: 105960.8488888889
      Variance HS100: 1.9902549248888895E7
      Variance HS1000: 2.6090474946711106E9
      Variance QS1: 32418.440000000002
      Variance QS10: 196872.22222222222
      Variance QS100: 2.8923743706666663E7
      Variance QS1000: 1.3071814139955556E9
      Variance MS1: 20368.715555555555
      Variance MS10: 150584.22222222222
      Variance MS100: 5005449.128888889
      Variance MS1000: 5005449.128888889

   --- Averages Reversed ---
      HeapSort1 average time(μs):0
      HeapSort10 average time(μs):2126
      HeapSort100 average time(μs):15775
      HeapSort1000 average time(μs):161679
      QuickSort1 average time(μs):254
      QuickSort10 average time(μs):935
      QuickSort100 average time(μs):11005
      QuickSort1000 average time(μs):86989
      MergeSort1 average time(μs):180
      MergeSort10 average time(μs):678
      MergeSort100 average time(μs):4783
      MergeSort1000 average time(μs):46860



------ RANDOM ------

   --- Round0 Random ---
      HeapSort0:PASS
      QuickSort0:PASS
      MergeSort0:PASS

   --- Round1 Random ---
      HeapSort1:PASS
      QuickSort1:PASS
      MergeSort1:PASS

   --- Round2 Random ---
      HeapSort2:PASS
      QuickSort2:PASS
      MergeSort2:PASS

   --- Round3 Random ---
      HeapSort3:PASS
      QuickSort3:PASS
      MergeSort3:PASS

   --- Variance Random ---
      Variance HS1: 709.4488888888887
      Variance HS10: 121082.04888888888
      Variance HS100: 2.4539589604444448E7
      Variance HS1000: 4.0147789105155554E9
      Variance QS1: 1113.8622222222225
      Variance QS10: 143578.99555555556
      Variance QS100: 2.060085844E7
      Variance QS1000: 3.1118773303333335E9
      Variance MS1: 22427.417777777777
      Variance MS10: 215152.29333333336
      Variance MS100: 1.144766398222222E7
      Variance MS1000: 1.144766398222222E7

   --- Averages Random ---
      HeapSort1 average time(μs):0
      HeapSort10 average time(μs):3285
      HeapSort100 average time(μs):32218
      HeapSort1000 average time(μs):372784
      QuickSort1 average time(μs):365
      QuickSort10 average time(μs):2198
      QuickSort100 average time(μs):26134
      QuickSort1000 average time(μs):272894
      MergeSort1 average time(μs):408
      MergeSort10 average time(μs):1923
      MergeSort100 average time(μs):16058
      MergeSort1000 average time(μs):190004